public class MyFirstClass {
    public static void main(String[] args) {
        System.out.println("Hello VS Code!");
        int x = 5;
        int y = 2;
        int sum = x + y;
        for (int i=1 ; i<=25;i++){
            int sum1 = sum;
            sum = sum1*2;
        }
        System.out.println("soma é: " + sum);

    }
    
}
