import java.util.Scanner;

import java.util.Scanner;

public class teste_scan {
    public static void main(String[] args){
        double x,y;
        Scanner input = new Scanner(System.in);
        System.out.print( "insere um n");
        x = input.nextDouble();
        System.out.println(x);
        input.close();
    }
    

}
