package aula4;

public class Funcoes {
    
}
